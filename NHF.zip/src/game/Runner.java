package game;

import game.Menu;

public class Runner {

    public static void main (String[] args){
        Menu menu=new Menu();
    }
}
